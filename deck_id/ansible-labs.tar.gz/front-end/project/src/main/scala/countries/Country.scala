package countries

import scala.scalajs.js.annotation.JSExportAll

@JSExportAll
case class Country(val code: String,
                   val name: String

)