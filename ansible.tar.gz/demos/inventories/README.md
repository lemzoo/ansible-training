Run these with 

```shell
$ ansible all -i … --list-hosts

```